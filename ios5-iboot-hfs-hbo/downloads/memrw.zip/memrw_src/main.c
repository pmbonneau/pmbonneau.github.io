/*
 *  iBex - Payload
 *
 *  Copyright (c) 2010, 2014-2015 xerub
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "plib.h"


#define TRANSFER_CHUNK 1000

int
_main(int argc, CmdArg *argv)
{
    if (!link(__builtin_return_address(0))) {
        return 0;
    }
    
    char mread[] = "mread";
    char mwrite[] = "mwrite";
    
    if (argc == 4 && strcmp(mread, argv[1].string) == 0)
    {
        unsigned int intaddr = argv[2].uinteger;
        unsigned int size = argv[3].inthex;
        
        while (size--)
        {
            unsigned char *data = (unsigned char*)intaddr;
            printf_("%02x",*data);
            intaddr = intaddr + 1;
        }
        
        printf_("\n");
        printf_("Read OK\n");
        return 0;
    }

    if (argc == 4 && strcmp(mwrite, argv[1].string) == 0)
    {
        unsigned int addr = argv[2].uinteger;
        unsigned char val = argv[3].inthex;
        printf_(argv[2].string);
        printf_(" = ");
        printf_(argv[3].string);
        *(unsigned char *)addr = val;
        
        printf_("\n");
        printf_("Write OK\n");
        return 0;
    }
    
    printf_("Usage :\n");
    printf_("-- Read from memory --\n");
    printf_("iRecovery>go mread [address] [Count]\n");
    printf_("iRecovery>go mread 0x9FF00000 0x8\n");
    printf_("\n");
    printf_("-- Write to memory --\n");
    printf_("iRecovery>go mwrite [address] [Data]\n");
    printf_("iRecovery>go mwrite 0x9FF00100 0xFF\n");
    return 0;
}

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmultichar"
#pragma GCC diagnostic pop
